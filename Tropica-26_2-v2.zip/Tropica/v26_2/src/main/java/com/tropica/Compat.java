package com.tropica;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/** Код, который отличается между версиями Minecraft. */
final class Compat {
    private Compat() {}

    /** Делает предмет «пьющимся» (берём компонент у обычного зелья). */
    static Item.Properties drinkable(Item.Properties p) {
        return p.component(DataComponents.CONSUMABLE, Items.POTION.components().get(DataComponents.CONSUMABLE));
    }

    /** Сообщение над хотбаром (раньше displayClientMessage(msg, true)). */
    static void actionBar(Player player, Component msg) {
        if (player instanceof ServerPlayer sp) sp.sendOverlayMessage(msg);
    }
}
