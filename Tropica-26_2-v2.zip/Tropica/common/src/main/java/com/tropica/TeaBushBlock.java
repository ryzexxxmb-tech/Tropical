package com.tropica;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.VegetationBlock;

public class TeaBushBlock extends AgedPlantBlock {
    public static final MapCodec<TeaBushBlock> CODEC = simpleCodec(TeaBushBlock::new);

    public TeaBushBlock(Properties props) { super(props); }

    @Override
    public MapCodec<? extends VegetationBlock> codec() { return CODEC; }
}
