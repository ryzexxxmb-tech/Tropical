package com.tropica;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/** Water filter: needs charcoal (CHARCOAL), filters up to 3 bottles of water (LEVEL) slowly into clean water (CLEAN). */
public class WaterFilterBlock extends Block {
    public static final MapCodec<WaterFilterBlock> CODEC = simpleCodec(WaterFilterBlock::new);
    public static final IntegerProperty CHARCOAL = IntegerProperty.create("charcoal", 0, 3);
    public static final IntegerProperty LEVEL = IntegerProperty.create("level", 0, 3);
    public static final BooleanProperty CLEAN = BooleanProperty.create("clean");

    public WaterFilterBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(CHARCOAL, 0).setValue(LEVEL, 0).setValue(CLEAN, false));
    }

    @Override
    public MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(CHARCOAL, LEVEL, CLEAN);
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(LEVEL) > 0 && !state.getValue(CLEAN) && random.nextInt(5) == 0) {
            level.setBlock(pos, state.setValue(CLEAN, true), 3);
        }
    }
}
