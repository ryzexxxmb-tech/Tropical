package com.tropica;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.VegetationBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Saplings that grow into palm / mango / banana trees. */
public abstract class TropicalSaplingBlock extends SimplePlantBlock {
    protected TropicalSaplingBlock(Properties props) { super(props); }

    protected abstract TropicalTrees.Kind kind();

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (level.getMaxLocalRawBrightness(pos.above()) >= 9 && random.nextInt(7) == 0) {
            level.removeBlock(pos, false);
            if (!TropicalTrees.generate(kind(), level, pos, random)) {
                level.setBlock(pos, state, 2);
            }
        }
    }

    public static class Palm extends TropicalSaplingBlock {
        public static final MapCodec<Palm> CODEC = simpleCodec(Palm::new);
        public Palm(Properties p) { super(p); }
        @Override public MapCodec<? extends VegetationBlock> codec() { return CODEC; }
        @Override protected TropicalTrees.Kind kind() { return TropicalTrees.Kind.PALM; }
    }

    public static class Mango extends TropicalSaplingBlock {
        public static final MapCodec<Mango> CODEC = simpleCodec(Mango::new);
        public Mango(Properties p) { super(p); }
        @Override public MapCodec<? extends VegetationBlock> codec() { return CODEC; }
        @Override protected TropicalTrees.Kind kind() { return TropicalTrees.Kind.MANGO; }
    }

    public static class Banana extends TropicalSaplingBlock {
        public static final MapCodec<Banana> CODEC = simpleCodec(Banana::new);
        public Banana(Properties p) { super(p); }
        @Override public MapCodec<? extends VegetationBlock> codec() { return CODEC; }
        @Override protected TropicalTrees.Kind kind() { return TropicalTrees.Kind.BANANA; }
    }
}
