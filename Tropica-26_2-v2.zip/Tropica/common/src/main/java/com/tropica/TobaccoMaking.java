package com.tropica;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Drying table logic: tobacco, tea, coffee and fruit (no block entity needed). */
public final class TobaccoMaking {
    private static Item[] raw;
    private static Item[] dried;

    private TobaccoMaking() {}

    public static void init() {
        raw = new Item[]{ModItems.TOBACCO_LEAF, ModItems.TEA_LEAF, ModItems.COFFEE_CHERRIES,
                ModItems.MANGO, ModItems.BANANA, ModItems.PINEAPPLE, ModItems.GRAPES};
        dried = new Item[]{ModItems.DRIED_TOBACCO, ModItems.DRIED_TEA, ModItems.COFFEE_BEANS,
                ModItems.DRIED_MANGO, ModItems.DRIED_BANANA, ModItems.DRIED_PINEAPPLE, ModItems.RAISINS};
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (hand != InteractionHand.MAIN_HAND || player.isSpectator()) return InteractionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            BlockState st = level.getBlockState(pos);
            if (!st.is(ModBlocks.DRYING_TABLE)) return InteractionResult.PASS;
            return table(player, level, pos, st, player.getItemInHand(hand));
        });
    }

    private static int kindOf(ItemStack held) {
        for (int i = 0; i < raw.length; i++) if (held.is(raw[i])) return i;
        return -1;
    }

    private static InteractionResult table(Player p, Level level, BlockPos pos, BlockState st, ItemStack held) {
        int n = st.getValue(DryingTableBlock.LEAVES);
        boolean isDried = st.getValue(DryingTableBlock.DRIED);
        int kind = st.getValue(DryingTableBlock.KIND);
        if (isDried && n > 0) {
            if (level instanceof ServerLevel) {
                ItemStack out = new ItemStack(dried[kind], n);
                if (!p.getInventory().add(out)) p.drop(out, false);
                level.setBlock(pos, st.setValue(DryingTableBlock.LEAVES, 0).setValue(DryingTableBlock.DRIED, false)
                        .setValue(DryingTableBlock.KIND, 0), 3);
            }
            return InteractionResult.SUCCESS;
        }
        int hk = kindOf(held);
        if (hk >= 0 && n < 4 && (n == 0 || hk == kind)) {
            if (level instanceof ServerLevel) {
                if (!p.getAbilities().instabuild) held.shrink(1);
                level.setBlock(pos, st.setValue(DryingTableBlock.LEAVES, n + 1).setValue(DryingTableBlock.DRIED, false)
                        .setValue(DryingTableBlock.KIND, hk), 3);
            }
            return InteractionResult.SUCCESS;
        }
        if (level instanceof ServerLevel) {
            String key = n == 0 ? "tropica.dry.empty" : "tropica.dry.drying";
            Compat.actionBar(p, Component.translatable(key, n));
        }
        return InteractionResult.SUCCESS;
    }
}
