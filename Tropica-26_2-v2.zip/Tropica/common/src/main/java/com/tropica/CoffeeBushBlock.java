package com.tropica;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.VegetationBlock;

public class CoffeeBushBlock extends AgedPlantBlock {
    public static final MapCodec<CoffeeBushBlock> CODEC = simpleCodec(CoffeeBushBlock::new);

    public CoffeeBushBlock(Properties props) { super(props); }

    @Override
    public MapCodec<? extends VegetationBlock> codec() { return CODEC; }
}
