package com.tropica;

import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.tags.BiomeTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Thirst: 0..800 points (shown as 10 drops). Drains over time, faster when sprinting / in hot places.
 * Low thirst slows you, empty thirst hurts (never kills). Drink water, coconut water, fruit, etc.
 */
public final class Thirst {
    public static final int MAX = 800;

    public static final AttachmentType<Integer> TYPE = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(Tropica.MOD_ID, "thirst"),
            b -> b.persistent(Codec.INT)
                    .initializer(() -> MAX)
                    .syncWith(ByteBufCodecs.VAR_INT, AttachmentSyncPredicate.targetOnly()));

    private static Item[] items;
    private static int[] GAIN;

    private static final Map<UUID, int[]> SEEN = new HashMap<>();
    private static final Map<UUID, Integer> LAST_SIP = new HashMap<>();

    private Thirst() {}

    public static void init() {
        List<Item> list = new ArrayList<>();
        List<Integer> gain = new ArrayList<>();
        Object[][] table = {
                {ModItems.COCONUT_WATER, 320}, {ModItems.FRUIT_SALAD, 200}, {ModItems.COCONUT, 120}, {ModItems.MANGO, 80},
                {ModItems.BANANA, 60}, {ModItems.PINEAPPLE, 100}, {Items.POTION, 240}, {Items.MILK_BUCKET, 160},
                {Items.MELON_SLICE, 80}, {Items.APPLE, 40}, {Items.SWEET_BERRIES, 40}, {Items.GLOW_BERRIES, 40},
                {Items.HONEY_BOTTLE, 40}, {ModItems.GRAPES, 60}, {ModItems.GRAPE_JUICE, 240},
                {ModItems.WINE, 40}, {ModItems.WINE_AGED, 40}, {ModItems.WINE_OLD, 40}, {ModItems.WINE_VINTAGE, 40},
                {ModItems.RUM, 20}, {ModItems.BEER, 120}, {ModItems.COCONUT_RUM, 200}, {ModItems.PINA_COLADA, 240},
                {ModItems.MANGO_SMOOTHIE, 280}, {ModItems.TEA, 280}, {ModItems.COFFEE, 160},
                {ModItems.BOILED_WATER, 320}, {ModItems.FILTERED_WATER, 280},
                // dried fruit: very filling, but makes you thirsty
                {ModItems.DRIED_MANGO, -40}, {ModItems.DRIED_BANANA, -40}, {ModItems.DRIED_PINEAPPLE, -40}, {ModItems.RAISINS, -40}};
        for (Object[] row : table) { list.add((Item) row[0]); gain.add((Integer) row[1]); }
        items = list.toArray(new Item[0]);
        GAIN = gain.stream().mapToInt(Integer::intValue).toArray();

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) tick(p);
        });

        // Drink from a water source with an empty hand
        UseItemCallback.EVENT.register((player, level, hand) -> {
            if (!(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;
            if (hand != InteractionHand.MAIN_HAND || !player.getItemInHand(hand).isEmpty()) return InteractionResult.PASS;
            if (sp.isCreative() || sp.isSpectator()) return InteractionResult.PASS;
            HitResult hr = player.pick(4.5, 1.0F, true);
            if (!(hr instanceof BlockHitResult bhr) || hr.getType() != HitResult.Type.BLOCK) return InteractionResult.PASS;
            FluidState fs = sl.getFluidState(bhr.getBlockPos());
            if (!fs.is(FluidTags.WATER) || !fs.isSource()) return InteractionResult.PASS;
            int last = LAST_SIP.getOrDefault(sp.getUUID(), -100);
            if (sp.tickCount - last < 12) return InteractionResult.SUCCESS;
            LAST_SIP.put(sp.getUUID(), sp.tickCount);
            boolean salty = sl.getBiome(bhr.getBlockPos()).is(BiomeTags.IS_OCEAN)
                    || sl.getBiome(bhr.getBlockPos()).is(BiomeTags.IS_BEACH);
            int t = sp.getAttachedOrCreate(TYPE);
            if (salty) {
                t = Math.max(0, t - 60);
                sp.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 120, 0));
                Compat.actionBar(sp, Component.translatable("tropica.thirst.salty"));
            } else {
                t = Math.min(MAX, t + 80);
                if (sp.getRandom().nextInt(10) < 6) {
                    sp.addEffect(new MobEffectInstance(MobEffects.HUNGER, 300, 0));
                    sp.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 200, 0));
                    Compat.actionBar(sp, Component.translatable("tropica.thirst.dirty"));
                }
            }
            sp.setAttached(TYPE, t);
            sp.swing(InteractionHand.MAIN_HAND);
            return InteractionResult.SUCCESS;
        });
    }

    private static int[] counts(ServerPlayer p) {
        int[] c = new int[items.length];
        for (int i = 0; i < items.length; i++) c[i] = p.getStats().getValue(Stats.ITEM_USED.get(items[i]));
        return c;
    }

    private static void tick(ServerPlayer p) {
        if (p.isSpectator() || !p.isAlive()) return;
        int[] now = counts(p);
        int[] last = SEEN.get(p.getUUID());
        int t = p.getAttachedOrCreate(TYPE);
        int old = t;

        if (last == null) {
            SEEN.put(p.getUUID(), now);
        } else {
            for (int i = 0; i < now.length; i++) {
                if (now[i] > last[i]) {
                    t = Math.max(0, Math.min(MAX, t + GAIN[i] * (now[i] - last[i])));
                    Drinks.apply(p, items[i]);
                }
            }
            SEEN.put(p.getUUID(), now);
        }

        if (!p.isCreative() && p.tickCount % 20 == 0) {
            ServerLevel sl = (ServerLevel) p.level();
            int drain = 1;
            if (p.isSprinting()) drain += 2;
            if (sl.getBiome(p.blockPosition()).value().getBaseTemperature() >= 1.0F) drain += 1;
            if (sl.dimension() == Level.NETHER) drain += 1;
            t = Math.max(0, t - drain);

            if (t <= 0) {
                p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 1, false, false, true));
            } else if (t <= 200) {
                p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 0, false, false, true));
            }
            if (t <= 0 && p.tickCount % 80 == 0 && p.getHealth() > 2.0F) {
                p.hurtServer(sl, sl.damageSources().generic(), 1.0F);
            }
        }

        if (old > 240 && t <= 240) {
            Compat.actionBar(p, Component.translatable("tropica.thirst.low"));
        }
        if (t != old) p.setAttached(TYPE, t);
    }
}
