package com.tropica;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Right-click logic for the wine press and the fermentation barrel (no block entities needed). */
public final class WineMaking {
    private WineMaking() {}

    public static void init() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (hand != InteractionHand.MAIN_HAND || player.isSpectator()) return InteractionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            BlockState st = level.getBlockState(pos);
            ItemStack held = player.getItemInHand(hand);
            if (st.is(ModBlocks.WINE_PRESS)) return press(player, level, pos, st, held);
            if (st.is(ModBlocks.WINE_BARREL)) return barrel(player, level, pos, st, held);
            return InteractionResult.PASS;
        });
    }

    private static void give(Player p, ItemStack s) {
        if (!p.getInventory().add(s)) p.drop(s, false);
    }

    private static void use(Player p, ItemStack held) {
        if (!p.getAbilities().instabuild) held.shrink(1);
    }

    private static InteractionResult press(Player p, Level level, BlockPos pos, BlockState st, ItemStack held) {
        int fill = st.getValue(WinePressBlock.FILL);
        boolean add = held.is(ModItems.GRAPES) && fill < 4;
        boolean take = held.is(Items.GLASS_BOTTLE) && fill >= 2;
        if (!add && !take) {
            if (level instanceof ServerLevel) {
                Compat.actionBar(p, Component.translatable("tropica.press.status", fill));
            }
            return InteractionResult.SUCCESS;
        }
        if (level instanceof ServerLevel) {
            if (add) {
                use(p, held);
                level.setBlock(pos, st.setValue(WinePressBlock.FILL, fill + 1), 3);
            } else {
                use(p, held);
                give(p, new ItemStack(ModItems.GRAPE_JUICE));
                level.setBlock(pos, st.setValue(WinePressBlock.FILL, fill - 2), 3);
            }
        }
        return InteractionResult.SUCCESS;
    }

    private static int kindOfInput(ItemStack held) {
        if (held.is(ModItems.GRAPE_JUICE)) return 0;
        if (held.is(ModItems.CANE_JUICE)) return 1;
        if (held.is(ModItems.WORT)) return 2;
        return -1;
    }

    private static ItemStack outputFor(int kind, int aged) {
        if (kind == 1) return new ItemStack(ModItems.RUM);
        if (kind == 2) return new ItemStack(ModItems.BEER);
        return new ItemStack(switch (aged) {
            case 1 -> ModItems.WINE_AGED;
            case 2 -> ModItems.WINE_OLD;
            case 3 -> ModItems.WINE_VINTAGE;
            default -> ModItems.WINE;
        });
    }

    private static InteractionResult barrel(Player p, Level level, BlockPos pos, BlockState st, ItemStack held) {
        int lvl = st.getValue(WineBarrelBlock.LEVEL);
        boolean ready = st.getValue(WineBarrelBlock.READY);
        int kind = st.getValue(WineBarrelBlock.KIND);
        int aged = st.getValue(WineBarrelBlock.AGED);
        int in = kindOfInput(held);
        boolean add = in >= 0 && lvl < 3 && !(ready && lvl > 0) && (lvl == 0 || in == kind);
        boolean take = held.is(Items.GLASS_BOTTLE) && ready && lvl > 0;
        if (!add && !take) {
            if (level instanceof ServerLevel) {
                if (lvl == 0) Compat.actionBar(p, Component.translatable("tropica.barrel.empty"));
                else if (!ready) Compat.actionBar(p, Component.translatable("tropica.barrel.fermenting", lvl));
                else {
                    String key = kind == 0 ? "tropica.barrel.ready.wine" + aged : kind == 1 ? "tropica.barrel.ready.rum" : "tropica.barrel.ready.beer";
                    Compat.actionBar(p, Component.translatable(key, lvl));
                }
            }
            return InteractionResult.SUCCESS;
        }
        if (level instanceof ServerLevel) {
            if (add) {
                use(p, held);
                give(p, new ItemStack(Items.GLASS_BOTTLE));
                level.setBlock(pos, st.setValue(WineBarrelBlock.LEVEL, lvl + 1).setValue(WineBarrelBlock.READY, false)
                        .setValue(WineBarrelBlock.KIND, in).setValue(WineBarrelBlock.AGED, 0), 3);
            } else {
                use(p, held);
                give(p, outputFor(kind, aged));
                int left = lvl - 1;
                level.setBlock(pos, st.setValue(WineBarrelBlock.LEVEL, left).setValue(WineBarrelBlock.READY, left > 0)
                        .setValue(WineBarrelBlock.AGED, left > 0 ? aged : 0), 3);
            }
        }
        return InteractionResult.SUCCESS;
    }
}
