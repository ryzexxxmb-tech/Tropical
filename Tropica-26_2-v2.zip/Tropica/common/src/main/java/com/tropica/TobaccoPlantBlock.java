package com.tropica;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.VegetationBlock;

public class TobaccoPlantBlock extends AgedPlantBlock {
    public static final MapCodec<TobaccoPlantBlock> CODEC = simpleCodec(TobaccoPlantBlock::new);

    public TobaccoPlantBlock(Properties props) { super(props); }

    @Override
    public MapCodec<? extends VegetationBlock> codec() { return CODEC; }
}
