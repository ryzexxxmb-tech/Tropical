package com.tropica;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;

/** If a support was removed, the hammock falls apart when someone tries to use it. */
public final class Hammocks {
    private Hammocks() {}

    public static void init() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            BlockState st = level.getBlockState(hit.getBlockPos());
            if (!st.is(ModBlocks.HAMMOCK) || player.isSpectator()) return InteractionResult.PASS;
            if (HammockBlock.hasSupports(level, hit.getBlockPos(), st)) return InteractionResult.PASS;
            if (level instanceof ServerLevel sl) {
                sl.destroyBlock(hit.getBlockPos(), true);
                Compat.actionBar(player, Component.translatable("tropica.hammock.fell"));
            }
            return InteractionResult.SUCCESS;
        });
    }
}
