package com.tropica;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;

public final class ThirstHud {
    private static final String[] DROP = {
            "...X...", "..XXX..", "..XXX..", ".XXXXX.", "XXXXXXX", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX.."};

    private ThirstHud() {}

    public static void init() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(Tropica.MOD_ID, "thirst"),
                (g, tick) -> render(g));
    }

    private static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || p.isCreative() || p.isSpectator()) return;
        int thirst = p.getAttachedOrElse(Thirst.TYPE, Thirst.MAX);
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        int y = h - 49;
        if (p.getAirSupply() < p.getMaxAirSupply()) y -= 10;
        int right = w / 2 + 91;
        int full = thirst <= 200 ? 0xFFE0707A : 0xFF3C8CFF;
        int emptyC = 0xFF2A2A3A;
        for (int i = 0; i < 10; i++) {
            int x = right - 8 * (i + 1) + 1;
            int amount = Math.max(0, Math.min(80, thirst - i * 80));
            int cols = Math.round(7f * amount / 80f);
            for (int r = 0; r < DROP.length; r++) {
                for (int c = 0; c < 7; c++) {
                    if (DROP[r].charAt(c) != (char) 88) continue;
                    g.fill(x + c, y + r, x + c + 1, y + r + 1, c < cols ? full : emptyC);
                }
            }
        }
    }
}
