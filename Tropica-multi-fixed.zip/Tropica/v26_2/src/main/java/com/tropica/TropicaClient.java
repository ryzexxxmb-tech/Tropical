package com.tropica;

import net.fabricmc.api.ClientModInitializer;

public class TropicaClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // 26.x picks the terrain layer (cutout) automatically from the texture.
        ThirstHud.init();
    }
}
