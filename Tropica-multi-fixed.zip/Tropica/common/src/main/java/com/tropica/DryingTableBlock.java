package com.tropica;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Holds up to 4 tobacco leaves (LEAVES). They dry over time (DRIED). */
public class DryingTableBlock extends Block {
    public static final MapCodec<DryingTableBlock> CODEC = simpleCodec(DryingTableBlock::new);
    public static final IntegerProperty LEAVES = IntegerProperty.create("leaves", 0, 4);
    public static final BooleanProperty DRIED = BooleanProperty.create("dried");
    /** what is drying: 0 tobacco, 1 tea, 2 coffee, 3 mango, 4 banana, 5 pineapple, 6 grapes */
    public static final IntegerProperty KIND = IntegerProperty.create("kind", 0, 6);
    private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 12.5, 16);

    public DryingTableBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(LEAVES, 0).setValue(DRIED, false).setValue(KIND, 0));
    }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LEAVES, DRIED, KIND);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(LEAVES) > 0 && !state.getValue(DRIED) && random.nextInt(4) == 0) {
            level.setBlock(pos, state.setValue(DRIED, true), 3);
        }
    }
}
