package com.tropica;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Cooking pot: holds up to 3 bottles of water. Boils them when placed over a heat source. */
public class CookingPotBlock extends Block {
    public static final MapCodec<CookingPotBlock> CODEC = simpleCodec(CookingPotBlock::new);
    public static final IntegerProperty WATER = IntegerProperty.create("water", 0, 3);
    public static final BooleanProperty BOILED = BooleanProperty.create("boiled");
    private static final VoxelShape SHAPE = Block.box(1, 0, 1, 15, 9, 15);

    public CookingPotBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(WATER, 0).setValue(BOILED, false));
    }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(WATER, BOILED);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    public static boolean hasHeat(BlockState below) {
        if (below.is(BlockTags.CAMPFIRES) && below.hasProperty(BlockStateProperties.LIT)
                && below.getValue(BlockStateProperties.LIT)) return true;
        return below.is(Blocks.FIRE) || below.is(Blocks.SOUL_FIRE) || below.is(Blocks.MAGMA_BLOCK) || below.is(Blocks.LAVA);
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(WATER) > 0 && !state.getValue(BOILED)
                && hasHeat(level.getBlockState(pos.below())) && random.nextInt(3) == 0) {
            level.setBlock(pos, state.setValue(BOILED, true), 3);
        }
    }
}
