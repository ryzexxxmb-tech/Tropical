package com.tropica;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

public class Tropica implements ModInitializer {
    public static final String MOD_ID = "tropica";

    private static Identifier id(String n) { return Identifier.fromNamespaceAndPath(MOD_ID, n); }

    private static ResourceKey<PlacedFeature> placed(String n) {
        return ResourceKey.create(Registries.PLACED_FEATURE, id(n));
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModItems.init();
        Thirst.init();
        WineMaking.init();
        TobaccoMaking.init();
        Smoking.init();
        WaterTreatment.init();
        Hammocks.init();

        Registry.register(BuiltInRegistries.FEATURE, id("palm_tree"), new TropicalTreeFeature(TropicalTrees.Kind.PALM));
        Registry.register(BuiltInRegistries.FEATURE, id("mango_tree"), new TropicalTreeFeature(TropicalTrees.Kind.MANGO));
        Registry.register(BuiltInRegistries.FEATURE, id("banana_tree"), new TropicalTreeFeature(TropicalTrees.Kind.BANANA));
        Registry.register(BuiltInRegistries.FEATURE, id("pineapple_patch"), new TropicalTreeFeature(TropicalTrees.Kind.PINEAPPLE));

        BiomeModifications.addFeature(BiomeSelectors.includeByKey(Biomes.BEACH),
                GenerationStep.Decoration.VEGETAL_DECORATION, placed("palm_tree"));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(Biomes.BEACH, Biomes.JUNGLE, Biomes.SPARSE_JUNGLE, Biomes.BAMBOO_JUNGLE),
                GenerationStep.Decoration.VEGETAL_DECORATION, placed("pineapple_patch"));
        Registry.register(BuiltInRegistries.FEATURE, id("tea_patch"), new TropicalTreeFeature(TropicalTrees.Kind.TEA));
        Registry.register(BuiltInRegistries.FEATURE, id("coffee_patch"), new TropicalTreeFeature(TropicalTrees.Kind.COFFEE));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(Biomes.BAMBOO_JUNGLE, Biomes.JUNGLE, Biomes.FOREST, Biomes.TAIGA),
                GenerationStep.Decoration.VEGETAL_DECORATION, placed("tea_patch"));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(Biomes.JUNGLE, Biomes.SPARSE_JUNGLE, Biomes.SAVANNA),
                GenerationStep.Decoration.VEGETAL_DECORATION, placed("coffee_patch"));
        Registry.register(BuiltInRegistries.FEATURE, id("tobacco_patch"), new TropicalTreeFeature(TropicalTrees.Kind.TOBACCO));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(Biomes.PLAINS, Biomes.SUNFLOWER_PLAINS, Biomes.SAVANNA, Biomes.FOREST, Biomes.SPARSE_JUNGLE),
                GenerationStep.Decoration.VEGETAL_DECORATION, placed("tobacco_patch"));
        Registry.register(BuiltInRegistries.FEATURE, id("grape_patch"), new TropicalTreeFeature(TropicalTrees.Kind.GRAPES));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(Biomes.PLAINS, Biomes.SUNFLOWER_PLAINS, Biomes.FOREST, Biomes.BIRCH_FOREST, Biomes.MEADOW),
                GenerationStep.Decoration.VEGETAL_DECORATION, placed("grape_patch"));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(Biomes.JUNGLE, Biomes.SPARSE_JUNGLE, Biomes.BAMBOO_JUNGLE, Biomes.SAVANNA),
                GenerationStep.Decoration.VEGETAL_DECORATION, placed("mango_tree"));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(Biomes.JUNGLE, Biomes.SPARSE_JUNGLE, Biomes.BAMBOO_JUNGLE, Biomes.BEACH),
                GenerationStep.Decoration.VEGETAL_DECORATION, placed("banana_tree"));

        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, id("tropica"), CreativeModeTab.builder()
                .title(Component.translatable("itemGroup.tropica"))
                .icon(() -> new ItemStack(ModItems.COCONUT))
                .displayItems((params, out) -> {
                    out.accept(ModItems.COCONUT);
                    out.accept(ModItems.BANANA);
                    out.accept(ModItems.MANGO);
                    out.accept(ModItems.PINEAPPLE);
                    out.accept(ModItems.COCONUT_WATER);
                    out.accept(ModItems.FRUIT_SALAD);
                    out.accept(ModItems.PINEAPPLE_TOP);
                    out.accept(ModItems.GRAPES);
                    out.accept(ModItems.GRAPE_JUICE);
                    out.accept(ModItems.WINE);
                    out.accept(ModItems.WINE_AGED);
                    out.accept(ModItems.WINE_OLD);
                    out.accept(ModItems.WINE_VINTAGE);
                    out.accept(ModItems.CANE_JUICE);
                    out.accept(ModItems.WORT);
                    out.accept(ModItems.RUM);
                    out.accept(ModItems.BEER);
                    out.accept(ModItems.COCONUT_RUM);
                    out.accept(ModItems.PINA_COLADA);
                    out.accept(ModItems.MANGO_SMOOTHIE);
                    out.accept(ModItems.TEA);
                    out.accept(ModItems.COFFEE);
                    out.accept(ModItems.TEA_SEEDS);
                    out.accept(ModItems.TEA_LEAF);
                    out.accept(ModItems.DRIED_TEA);
                    out.accept(ModItems.COFFEE_SEEDS);
                    out.accept(ModItems.COFFEE_CHERRIES);
                    out.accept(ModItems.COFFEE_BEANS);
                    out.accept(ModItems.DRIED_MANGO);
                    out.accept(ModItems.DRIED_BANANA);
                    out.accept(ModItems.DRIED_PINEAPPLE);
                    out.accept(ModItems.RAISINS);
                    out.accept(ModItems.WINE_PRESS);
                    out.accept(ModItems.WINE_BARREL);
                    out.accept(ModItems.TOBACCO_SEEDS);
                    out.accept(ModItems.TOBACCO_LEAF);
                    out.accept(ModItems.DRIED_TOBACCO);
                    out.accept(ModItems.CIGARETTE);
                    out.accept(ModItems.HAMMOCK);
                    out.accept(ModItems.COOKING_POT);
                    out.accept(ModItems.WATER_FILTER);
                    out.accept(ModItems.BOILED_WATER);
                    out.accept(ModItems.FILTERED_WATER);
                    out.accept(ModItems.DRYING_TABLE);
                    out.accept(ModItems.PALM_LOG);
                    out.accept(ModItems.PALM_PLANKS);
                    out.accept(ModItems.PALM_LEAVES);
                    out.accept(ModItems.MANGO_LEAVES);
                    out.accept(ModItems.BANANA_LEAVES);
                    out.accept(ModItems.PALM_SAPLING);
                    out.accept(ModItems.MANGO_SAPLING);
                    out.accept(ModItems.BANANA_SAPLING);
                }).build());
    }
}
