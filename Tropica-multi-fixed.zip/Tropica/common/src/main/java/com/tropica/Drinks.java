package com.tropica;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Item;

/** Status effects of alcohol, cocktails and hot drinks. 20 ticks = 1 second. */
public final class Drinks {
    private Drinks() {}

    private static void fx(ServerPlayer p, net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> e, int ticks, int amp) {
        p.addEffect(new MobEffectInstance(e, ticks, amp));
    }

    public static void apply(ServerPlayer p, Item it) {
        // ---- wine: the longer it aged, the better
        if (it == ModItems.WINE) {                       // young
            fx(p, MobEffects.NAUSEA, 200, 0);            // 10 s
            fx(p, MobEffects.STRENGTH, 1800, 1);         // 1.5 min
            fx(p, MobEffects.SPEED, 1800, 1);
        } else if (it == ModItems.WINE_AGED) {
            fx(p, MobEffects.NAUSEA, 100, 0);            // 5 s
            fx(p, MobEffects.STRENGTH, 3600, 1);         // 3 min
            fx(p, MobEffects.SPEED, 3600, 1);
        } else if (it == ModItems.WINE_OLD) {
            fx(p, MobEffects.STRENGTH, 5400, 1);         // 4.5 min
            fx(p, MobEffects.SPEED, 5400, 1);
            fx(p, MobEffects.RESISTANCE, 3600, 0);       // 3 min
        } else if (it == ModItems.WINE_VINTAGE) {
            fx(p, MobEffects.STRENGTH, 7200, 2);         // Strength III, 6 min
            fx(p, MobEffects.SPEED, 7200, 1);
            fx(p, MobEffects.RESISTANCE, 3600, 1);       // Resistance II, 3 min
            fx(p, MobEffects.REGENERATION, 300, 0);      // 15 s
        }
        // ---- spirits and beer
        else if (it == ModItems.RUM) {
            fx(p, MobEffects.STRENGTH, 1200, 1);         // 1 min
            fx(p, MobEffects.FIRE_RESISTANCE, 2400, 0);  // 2 min
            fx(p, MobEffects.NAUSEA, 160, 0);
        } else if (it == ModItems.BEER) {
            fx(p, MobEffects.RESISTANCE, 1200, 0);       // 1 min
            fx(p, MobEffects.NAUSEA, 100, 0);
        }
        // ---- cocktails
        else if (it == ModItems.COCONUT_RUM) {
            fx(p, MobEffects.STRENGTH, 1200, 1);
            fx(p, MobEffects.SPEED, 1200, 0);
            fx(p, MobEffects.NAUSEA, 100, 0);
        } else if (it == ModItems.PINA_COLADA) {
            fx(p, MobEffects.FIRE_RESISTANCE, 3600, 0);
            fx(p, MobEffects.WATER_BREATHING, 3600, 0);
            fx(p, MobEffects.NAUSEA, 100, 0);
        } else if (it == ModItems.MANGO_SMOOTHIE) {
            fx(p, MobEffects.REGENERATION, 200, 0);      // 10 s
            fx(p, MobEffects.JUMP_BOOST, 1200, 1);
        }
        // ---- hot drinks
        else if (it == ModItems.TEA) {
            fx(p, MobEffects.REGENERATION, 200, 0);
            p.removeEffect(MobEffects.NAUSEA);           // tea calms the stomach
            p.removeEffect(MobEffects.HUNGER);
        } else if (it == ModItems.COFFEE) {
            fx(p, MobEffects.HASTE, 2400, 1);            // Haste II, 2 min
            fx(p, MobEffects.SPEED, 1200, 0);
        }
    }
}
