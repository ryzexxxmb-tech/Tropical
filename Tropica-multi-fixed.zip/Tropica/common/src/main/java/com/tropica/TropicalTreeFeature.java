package com.tropica;

import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

public class TropicalTreeFeature extends Feature<NoneFeatureConfiguration> {
    private final TropicalTrees.Kind kind;

    public TropicalTreeFeature(TropicalTrees.Kind kind) {
        super(NoneFeatureConfiguration.CODEC);
        this.kind = kind;
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        return TropicalTrees.generate(kind, ctx.level(), ctx.origin(), ctx.random());
    }
}
