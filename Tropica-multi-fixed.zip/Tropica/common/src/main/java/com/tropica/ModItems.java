package com.tropica;

import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BedItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Consumables;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;

import java.util.function.Function;

public final class ModItems {
    public static final Item COCONUT = food("coconut", 3, 0.3F);
    public static final Item BANANA = food("banana", 4, 0.4F);
    public static final Item MANGO = food("mango", 5, 0.5F);
    public static final Item PINEAPPLE = food("pineapple", 4, 0.4F);

    public static final Item COCONUT_WATER = drink("coconut_water");
    public static final Item FRUIT_SALAD = register("fruit_salad", Item::new, p -> p
            .food(new FoodProperties.Builder().nutrition(10).saturationModifier(0.7F).build())
            .usingConvertsTo(Items.BOWL).stacksTo(1));

    public static final Item GRAPES = register("grapes", p -> new BlockItem(ModBlocks.GRAPE_VINE, p), p -> p
            .food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.2F).build()));
    public static final Item GRAPE_JUICE = drink("grape_juice");
    public static final Item WINE = drink("wine");
    public static final Item BOILED_WATER = drink("boiled_water");
    public static final Item FILTERED_WATER = drink("filtered_water");
    public static final Item COOKING_POT = blockItem("cooking_pot", ModBlocks.COOKING_POT);
    public static final Item WATER_FILTER = blockItem("water_filter", ModBlocks.WATER_FILTER);
    public static final Item WINE_AGED = drink("wine_aged");
    public static final Item WINE_OLD = drink("wine_old");
    public static final Item WINE_VINTAGE = drink("wine_vintage");
    public static final Item CANE_JUICE = stack16("cane_juice");
    public static final Item WORT = stack16("wort");
    public static final Item RUM = drink("rum");
    public static final Item BEER = drink("beer");
    public static final Item COCONUT_RUM = cup("coconut_rum");
    public static final Item PINA_COLADA = cup("pina_colada");
    public static final Item MANGO_SMOOTHIE = cup("mango_smoothie");
    public static final Item TEA = cup("tea");
    public static final Item COFFEE = cup("coffee");
    public static final Item TEA_SEEDS = register("tea_seeds", p -> new BlockItem(ModBlocks.TEA_BUSH, p), p -> p);
    public static final Item COFFEE_SEEDS = register("coffee_seeds", p -> new BlockItem(ModBlocks.COFFEE_BUSH, p), p -> p);
    public static final Item TEA_LEAF = register("tea_leaf", Item::new, p -> p);
    public static final Item DRIED_TEA = register("dried_tea", Item::new, p -> p);
    public static final Item COFFEE_CHERRIES = register("coffee_cherries", Item::new, p -> p);
    public static final Item COFFEE_BEANS = register("coffee_beans", Item::new, p -> p);
    public static final Item DRIED_MANGO = food("dried_mango", 7, 0.9F);
    public static final Item DRIED_BANANA = food("dried_banana", 6, 0.8F);
    public static final Item DRIED_PINEAPPLE = food("dried_pineapple", 6, 0.8F);
    public static final Item RAISINS = food("raisins", 4, 0.6F);
    public static final Item WINE_PRESS = blockItem("wine_press", ModBlocks.WINE_PRESS);
    public static final Item WINE_BARREL = blockItem("wine_barrel", ModBlocks.WINE_BARREL);

    public static final Item TOBACCO_SEEDS = register("tobacco_seeds", p -> new BlockItem(ModBlocks.TOBACCO_PLANT, p), p -> p);
    public static final Item TOBACCO_LEAF = register("tobacco_leaf", Item::new, p -> p);
    public static final Item DRIED_TOBACCO = register("dried_tobacco", Item::new, p -> p);
    public static final Item CIGARETTE = register("cigarette", Item::new, p -> p);
    public static final Item DRYING_TABLE = blockItem("drying_table", ModBlocks.DRYING_TABLE);

    public static final Item HAMMOCK = register("hammock", p -> new BedItem(ModBlocks.HAMMOCK, p),
            p -> p.useBlockDescriptionPrefix().stacksTo(1));

    public static final Item PALM_LOG = blockItem("palm_log", ModBlocks.PALM_LOG);
    public static final Item PALM_PLANKS = blockItem("palm_planks", ModBlocks.PALM_PLANKS);
    public static final Item PALM_LEAVES = blockItem("palm_leaves", ModBlocks.PALM_LEAVES);
    public static final Item MANGO_LEAVES = blockItem("mango_leaves", ModBlocks.MANGO_LEAVES);
    public static final Item BANANA_LEAVES = blockItem("banana_leaves", ModBlocks.BANANA_LEAVES);
    public static final Item PALM_SAPLING = blockItem("palm_sapling", ModBlocks.PALM_SAPLING);
    public static final Item MANGO_SAPLING = blockItem("mango_sapling", ModBlocks.MANGO_SAPLING);
    public static final Item BANANA_SAPLING = blockItem("banana_sapling", ModBlocks.BANANA_SAPLING);
    public static final Item PINEAPPLE_TOP = blockItem("pineapple_top", ModBlocks.PINEAPPLE_PLANT);

    private static Item drink(String name) {
        return register(name, Item::new, p -> p
                .component(DataComponents.CONSUMABLE, Consumables.DEFAULT_DRINK)
                .usingConvertsTo(Items.GLASS_BOTTLE).stacksTo(16));
    }

    private static Item cup(String name) {
        return register(name, Item::new, p -> p
                .component(DataComponents.CONSUMABLE, Consumables.DEFAULT_DRINK).stacksTo(16));
    }

    private static Item stack16(String name) {
        return register(name, Item::new, p -> p.stacksTo(16));
    }

    private static Item food(String name, int nutrition, float sat) {
        return register(name, Item::new, p -> p.food(
                new FoodProperties.Builder().nutrition(nutrition).saturationModifier(sat).build()));
    }

    private static Item register(String name, Function<Item.Properties, Item> factory,
                                 Function<Item.Properties, Item.Properties> cfg) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(Tropica.MOD_ID, name));
        Item.Properties props = cfg.apply(new Item.Properties()).setId(key);
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props));
    }

    private static Item blockItem(String name, Block block) {
        return register(name, p -> new BlockItem(block, p), p -> p.useBlockDescriptionPrefix());
    }

    public static void init() {}
}
