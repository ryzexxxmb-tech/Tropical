package com.tropica;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/** Holds up to 4 grapes (FILL); two grapes give one bottle of juice. */
public class WinePressBlock extends Block {
    public static final MapCodec<WinePressBlock> CODEC = simpleCodec(WinePressBlock::new);
    public static final IntegerProperty FILL = IntegerProperty.create("fill", 0, 4);

    public WinePressBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FILL, 0));
    }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FILL);
    }
}
