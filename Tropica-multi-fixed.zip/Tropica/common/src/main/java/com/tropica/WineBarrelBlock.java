package com.tropica;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/**
 * Fermentation barrel. Holds up to 3 bottles (LEVEL) of one liquid (KIND: 0 wine, 1 rum, 2 beer).
 * The liquid ferments (READY). Wine keeps aging afterwards (AGED 0..3: young, aged, old, vintage).
 */
public class WineBarrelBlock extends Block {
    public static final MapCodec<WineBarrelBlock> CODEC = simpleCodec(WineBarrelBlock::new);
    public static final IntegerProperty LEVEL = IntegerProperty.create("level", 0, 3);
    public static final BooleanProperty READY = BooleanProperty.create("ready");
    public static final IntegerProperty KIND = IntegerProperty.create("kind", 0, 2);
    public static final IntegerProperty AGED = IntegerProperty.create("aged", 0, 3);

    /** random-tick chances: 1 in N per random tick */
    private static final int[] FERMENT = {3, 4, 2};   // wine, rum, beer
    private static final int AGING = 5;                // wine: one aging step

    public WineBarrelBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(LEVEL, 0).setValue(READY, false)
                .setValue(KIND, 0).setValue(AGED, 0));
    }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LEVEL, READY, KIND, AGED);
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(LEVEL) <= 0) return;
        int kind = state.getValue(KIND);
        if (!state.getValue(READY)) {
            if (random.nextInt(FERMENT[kind]) == 0) level.setBlock(pos, state.setValue(READY, true), 3);
        } else if (kind == 0) {
            int aged = state.getValue(AGED);
            if (aged < 3 && random.nextInt(AGING) == 0) level.setBlock(pos, state.setValue(AGED, aged + 1), 3);
        }
    }
}
