package com.tropica;

import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Cigarettes: Speed I for 3 minutes. Smoking a lot builds a dependence.
 * Addicted players who go without a cigarette for too long take 1 heart of damage every 30 seconds.
 */
public final class Smoking {
    // ---- tuning (game ticks, 20 ticks = 1 second)
    private static final int SPEED_TICKS = 3 * 60 * 20;          // speed 1 for 3 minutes
    private static final int ADDICTION_AT = 5;                    // cigarettes in a short time -> addiction
    private static final long DECAY_TICKS = 5 * 60 * 20L;         // not addicted: -1 "smoke point" per 5 min
    private static final long WITHDRAWAL_START = 5 * 60 * 20L;    // addicted: damage starts after 5 min without smoking
    private static final long WITHDRAWAL_PERIOD = 30 * 20L;       // ...and repeats every 30 s
    private static final long CURE_TICKS = 25 * 60 * 20L;         // 25 min without smoking -> addiction gone
    private static final float WITHDRAWAL_DAMAGE = 2.0F;          // 1 heart

    public static final AttachmentType<Integer> SMOKES = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(Tropica.MOD_ID, "smokes"),
            b -> b.persistent(Codec.INT).initializer(() -> 0).copyOnDeath());
    public static final AttachmentType<Boolean> ADDICTED = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(Tropica.MOD_ID, "addicted"),
            b -> b.persistent(Codec.BOOL).initializer(() -> false).copyOnDeath());
    public static final AttachmentType<Long> LAST_SMOKE = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(Tropica.MOD_ID, "last_smoke"),
            b -> b.persistent(Codec.LONG).initializer(() -> 0L).copyOnDeath());

    private static final Map<UUID, Integer> LAST_USE = new HashMap<>();

    private Smoking() {}

    public static void init() {
        UseItemCallback.EVENT.register((player, level, hand) -> {
            ItemStack held = player.getItemInHand(hand);
            if (!held.is(ModItems.CIGARETTE) || player.isSpectator()) return InteractionResult.PASS;
            if (!(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer sp)) return InteractionResult.SUCCESS;
            Integer prev = LAST_USE.get(sp.getUUID());
            if (prev != null && sp.tickCount - prev < 20) return InteractionResult.SUCCESS;
            LAST_USE.put(sp.getUUID(), sp.tickCount);

            if (!sp.getAbilities().instabuild) held.shrink(1);
            sp.addEffect(new MobEffectInstance(MobEffects.SPEED, SPEED_TICKS, 0));

            long now = sl.getGameTime();
            int smokes = sp.getAttachedOrCreate(SMOKES) + 1;
            sp.setAttached(SMOKES, smokes);
            sp.setAttached(LAST_SMOKE, now);
            if (!sp.getAttachedOrCreate(ADDICTED) && smokes >= ADDICTION_AT) {
                sp.setAttached(ADDICTED, true);
                sp.displayClientMessage(Component.translatable("tropica.smoke.addicted"), true);
            }
            sp.swing(hand);
            return InteractionResult.SUCCESS;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) tick(p);
        });
    }

    private static void tick(ServerPlayer p) {
        if (p.tickCount % 20 != 0 || p.isCreative() || p.isSpectator() || !p.isAlive()) return;
        ServerLevel sl = (ServerLevel) p.level();
        long now = sl.getGameTime();
        long last = p.getAttachedOrCreate(LAST_SMOKE);
        boolean addicted = p.getAttachedOrCreate(ADDICTED);

        if (!addicted) {
            int smokes = p.getAttachedOrCreate(SMOKES);
            if (smokes > 0 && now - last > DECAY_TICKS) {
                p.setAttached(SMOKES, smokes - 1);
                p.setAttached(LAST_SMOKE, now);
            }
            return;
        }

        long away = now - last;
        if (away >= CURE_TICKS) {
            p.setAttached(ADDICTED, false);
            p.setAttached(SMOKES, 0);
            p.displayClientMessage(Component.translatable("tropica.smoke.cured"), true);
            return;
        }
        if (away >= WITHDRAWAL_START && (away - WITHDRAWAL_START) % WITHDRAWAL_PERIOD < 20) {
            p.displayClientMessage(Component.translatable("tropica.smoke.craving"), true);
            if (p.getHealth() > WITHDRAWAL_DAMAGE) {
                p.hurtServer(sl, sl.damageSources().generic(), WITHDRAWAL_DAMAGE);
            }
        }
    }
}
