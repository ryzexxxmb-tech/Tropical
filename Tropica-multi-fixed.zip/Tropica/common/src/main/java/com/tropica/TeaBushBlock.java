package com.tropica;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.BushBlock;

public class TeaBushBlock extends AgedPlantBlock {
    public static final MapCodec<TeaBushBlock> CODEC = simpleCodec(TeaBushBlock::new);

    public TeaBushBlock(Properties props) { super(props); }

    @Override
    protected MapCodec<? extends BushBlock> codec() { return CODEC; }
}
