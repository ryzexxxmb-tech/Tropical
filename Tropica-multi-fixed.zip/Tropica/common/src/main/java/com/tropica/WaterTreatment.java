package com.tropica;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Right-click logic for the cooking pot (boils water) and the water filter (needs charcoal). */
public final class WaterTreatment {
    private WaterTreatment() {}

    public static void init() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (hand != InteractionHand.MAIN_HAND || player.isSpectator()) return InteractionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            BlockState st = level.getBlockState(pos);
            ItemStack held = player.getItemInHand(hand);
            if (st.is(ModBlocks.COOKING_POT)) return pot(player, level, pos, st, held);
            if (st.is(ModBlocks.WATER_FILTER)) return filter(player, level, pos, st, held);
            return InteractionResult.PASS;
        });
    }

    private static void give(Player p, ItemStack s) {
        if (!p.getInventory().add(s)) p.drop(s, false);
    }

    private static void use(Player p, ItemStack held) {
        if (!p.getAbilities().instabuild) held.shrink(1);
    }

    private static void msg(Player p, Level level, String key, int n) {
        if (level instanceof ServerLevel) p.displayClientMessage(Component.translatable(key, n), true);
    }

    // ------------------------------------------------ pot
    private static InteractionResult pot(Player p, Level level, BlockPos pos, BlockState st, ItemStack held) {
        int water = st.getValue(CookingPotBlock.WATER);
        boolean boiled = st.getValue(CookingPotBlock.BOILED);
        boolean fill = held.is(Items.WATER_BUCKET) && water == 0;
        boolean take = held.is(Items.GLASS_BOTTLE) && boiled && water > 0;
        if (!fill && !take) {
            if (water == 0) msg(p, level, "tropica.pot.empty", 0);
            else if (boiled) msg(p, level, "tropica.pot.ready", water);
            else if (!CookingPotBlock.hasHeat(level.getBlockState(pos.below()))) msg(p, level, "tropica.pot.cold", water);
            else msg(p, level, "tropica.pot.heating", water);
            return InteractionResult.SUCCESS;
        }
        if (level instanceof ServerLevel) {
            if (fill) {
                if (!p.getAbilities().instabuild) { held.shrink(1); give(p, new ItemStack(Items.BUCKET)); }
                level.setBlock(pos, st.setValue(CookingPotBlock.WATER, 3).setValue(CookingPotBlock.BOILED, false), 3);
            } else {
                use(p, held);
                give(p, new ItemStack(ModItems.BOILED_WATER));
                int left = water - 1;
                level.setBlock(pos, st.setValue(CookingPotBlock.WATER, left).setValue(CookingPotBlock.BOILED, left > 0), 3);
            }
        }
        return InteractionResult.SUCCESS;
    }

    // ------------------------------------------------ filter
    private static InteractionResult filter(Player p, Level level, BlockPos pos, BlockState st, ItemStack held) {
        int coal = st.getValue(WaterFilterBlock.CHARCOAL);
        int lvl = st.getValue(WaterFilterBlock.LEVEL);
        boolean clean = st.getValue(WaterFilterBlock.CLEAN);
        boolean addCoal = held.is(Items.CHARCOAL) && coal < 3;
        boolean pour = held.is(Items.WATER_BUCKET) && lvl == 0 && coal > 0;
        boolean take = held.is(Items.GLASS_BOTTLE) && clean && lvl > 0;
        if (!addCoal && !pour && !take) {
            if (lvl == 0 && coal == 0) msg(p, level, "tropica.filter.nocharcoal", 0);
            else if (lvl == 0) msg(p, level, "tropica.filter.empty", coal);
            else if (clean) msg(p, level, "tropica.filter.ready", lvl);
            else msg(p, level, "tropica.filter.working", lvl);
            return InteractionResult.SUCCESS;
        }
        if (level instanceof ServerLevel) {
            if (addCoal) {
                use(p, held);
                level.setBlock(pos, st.setValue(WaterFilterBlock.CHARCOAL, coal + 1), 3);
            } else if (pour) {
                if (!p.getAbilities().instabuild) { held.shrink(1); give(p, new ItemStack(Items.BUCKET)); }
                level.setBlock(pos, st.setValue(WaterFilterBlock.CHARCOAL, coal - 1)
                        .setValue(WaterFilterBlock.LEVEL, 3).setValue(WaterFilterBlock.CLEAN, false), 3);
            } else {
                use(p, held);
                give(p, new ItemStack(ModItems.FILTERED_WATER));
                int left = lvl - 1;
                level.setBlock(pos, st.setValue(WaterFilterBlock.LEVEL, left).setValue(WaterFilterBlock.CLEAN, left > 0), 3);
            }
        }
        return InteractionResult.SUCCESS;
    }
}
