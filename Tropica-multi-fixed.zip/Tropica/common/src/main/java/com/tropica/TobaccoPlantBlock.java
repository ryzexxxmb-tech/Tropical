package com.tropica;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.BushBlock;

public class TobaccoPlantBlock extends AgedPlantBlock {
    public static final MapCodec<TobaccoPlantBlock> CODEC = simpleCodec(TobaccoPlantBlock::new);

    public TobaccoPlantBlock(Properties props) { super(props); }

    @Override
    protected MapCodec<? extends BushBlock> codec() { return CODEC; }
}
