package com.tropica;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.TintedParticleLeavesBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;

import java.util.function.Function;

public final class ModBlocks {
    public static final Block PALM_LOG = register("palm_log", RotatedPillarBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.0F).sound(SoundType.WOOD).ignitedByLava());
    public static final Block PALM_PLANKS = register("palm_planks", Block::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.SAND).strength(2.0F, 3.0F).sound(SoundType.WOOD).ignitedByLava());

    public static final Block PALM_LEAVES = register("palm_leaves", leaves(), leafProps());
    public static final Block MANGO_LEAVES = register("mango_leaves", leaves(), leafProps());
    public static final Block BANANA_LEAVES = register("banana_leaves", leaves(), leafProps());

    public static final Block PALM_SAPLING = register("palm_sapling", TropicalSaplingBlock.Palm::new, plantProps(true));
    public static final Block MANGO_SAPLING = register("mango_sapling", TropicalSaplingBlock.Mango::new, plantProps(true));
    public static final Block BANANA_SAPLING = register("banana_sapling", TropicalSaplingBlock.Banana::new, plantProps(true));
    public static final Block PINEAPPLE_PLANT = register("pineapple_plant", SimplePlantBlock::new, plantProps(false));

    public static final Block GRAPE_VINE = register("grape_vine", GrapeVineBlock::new, plantProps(true));
    public static final Block WINE_PRESS = register("wine_press", WinePressBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.5F).sound(SoundType.WOOD).noOcclusion());
    public static final Block WINE_BARREL = register("wine_barrel", WineBarrelBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.5F).sound(SoundType.WOOD).randomTicks().noOcclusion());

    public static final Block TEA_BUSH = register("tea_bush", TeaBushBlock::new, plantProps(true));
    public static final Block COFFEE_BUSH = register("coffee_bush", CoffeeBushBlock::new, plantProps(true));
    public static final Block TOBACCO_PLANT = register("tobacco_plant", TobaccoPlantBlock::new, plantProps(true));
    public static final Block DRYING_TABLE = register("drying_table", DryingTableBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.0F).sound(SoundType.WOOD).randomTicks().noOcclusion());

    public static final Block COOKING_POT = register("cooking_pot", CookingPotBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(2.0F).sound(SoundType.METAL).randomTicks().noOcclusion());
    public static final Block WATER_FILTER = register("water_filter", WaterFilterBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.0F).sound(SoundType.WOOD).randomTicks().noOcclusion());

    public static final Block HAMMOCK = register("hammock", HammockBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.WOOL).sound(SoundType.WOOL).strength(0.2F)
                    .noOcclusion().ignitedByLava().pushReaction(PushReaction.DESTROY));

    private static Function<BlockBehaviour.Properties, Block> leaves() {
        return p -> new TintedParticleLeavesBlock(0.01F, p);
    }

    private static BlockBehaviour.Properties leafProps() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.PLANT).strength(0.2F).randomTicks()
                .sound(SoundType.GRASS).noOcclusion().ignitedByLava()
                .isValidSpawn((s, g, p, t) -> false)
                .isSuffocating((s, g, p) -> false)
                .isViewBlocking((s, g, p) -> false);
    }

    private static BlockBehaviour.Properties plantProps(boolean ticks) {
        BlockBehaviour.Properties p = BlockBehaviour.Properties.of().mapColor(MapColor.PLANT).noCollision()
                .instabreak().sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY);
        return ticks ? p.randomTicks() : p;
    }

    private static Block register(String name, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties props) {
        ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(Tropica.MOD_ID, name));
        return Registry.register(BuiltInRegistries.BLOCK, key, factory.apply(props.setId(key)));
    }

    public static void init() {}
}
