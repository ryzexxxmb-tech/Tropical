package com.tropica;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/** All tree / patch generation (worldgen features and saplings share this code). */
public final class TropicalTrees {
    public enum Kind { PALM, MANGO, BANANA, PINEAPPLE, GRAPES, TOBACCO, TEA, COFFEE }

    private static final int[][] CARD = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private static final int[][] DIAG = {{1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
    private static final int[] PROF_LONG = {1, 1, 0, -1, -2};
    private static final int[] PROF_DIAG = {1, 0, -1, -2};
    private static final int[] PROF_BANANA = {1, 0, -1};

    private TropicalTrees() {}

    public static boolean generate(Kind kind, WorldGenLevel level, BlockPos pos, RandomSource r) {
        return switch (kind) {
            case PALM -> palm(level, pos, r);
            case MANGO -> mango(level, pos, r);
            case BANANA -> banana(level, pos, r);
            case PINEAPPLE -> pineapples(level, pos, r);
            case GRAPES -> grapes(level, pos, r);
            case TOBACCO -> tobacco(level, pos, r);
            case TEA -> wild(level, pos, r, ModBlocks.TEA_BUSH);
            case COFFEE -> wild(level, pos, r, ModBlocks.COFFEE_BUSH);
        };
    }

    // ------------------------------------------------------------ helpers
    private static boolean isGround(WorldGenLevel level, BlockPos p) {
        BlockState s = level.getBlockState(p);
        return s.is(BlockTags.SAND) || s.is(BlockTags.DIRT);
    }

    private static boolean free(WorldGenLevel level, BlockPos p) {
        BlockState s = level.getBlockState(p);
        if (!s.getFluidState().isEmpty()) return false;
        return s.isAir() || s.canBeReplaced() || s.is(BlockTags.LEAVES);
    }

    private static void put(WorldGenLevel level, BlockPos p, BlockState st) {
        if (free(level, p)) level.setBlock(p, st, 3);
    }

    private static BlockState leaf(Block b) {
        return b.defaultBlockState().setValue(LeavesBlock.DISTANCE, 1).setValue(LeavesBlock.PERSISTENT, false);
    }

    private static void frond(WorldGenLevel level, BlockPos top, int dx, int dz, int[] prof, BlockState leaf, boolean wide) {
        for (int k = 1; k <= prof.length; k++) {
            BlockPos p = top.offset(dx * k, prof[k - 1], dz * k);
            put(level, p, leaf);
            if ((k == 2 || k == 3) && dx * dz == 0) {
                put(level, p.offset(dz, wide ? 0 : -1, dx), leaf);
                put(level, p.offset(-dz, wide ? 0 : -1, -dx), leaf);
            }
        }
    }

    // ------------------------------------------------------------ palm
    private static boolean palm(WorldGenLevel level, BlockPos base, RandomSource r) {
        if (!isGround(level, base.below()) || !free(level, base)) return false;
        int h = 7 + r.nextInt(5);
        int[] d = CARD[r.nextInt(4)];
        int lean = 1 + r.nextInt(3);
        List<BlockPos> trunk = new ArrayList<>();
        for (int i = 0; i < h; i++) {
            double t = (double) i / (h - 1);
            int off = (int) Math.round(lean * t * t);
            BlockPos p = base.offset(d[0] * off, i, d[1] * off);
            if (!free(level, p)) {
                if (i < 5) return false;
                break;
            }
            trunk.add(p);
        }
        BlockState log = ModBlocks.PALM_LOG.defaultBlockState();
        for (BlockPos p : trunk) level.setBlock(p, log, 3);
        BlockPos top = trunk.get(trunk.size() - 1);
        BlockState lv = leaf(ModBlocks.PALM_LEAVES);
        put(level, top.above(), lv);
        for (int[] c : CARD) put(level, top.offset(c[0], 0, c[1]), lv);
        for (int[] c : DIAG) put(level, top.offset(c[0], 0, c[1]), lv);
        for (int[] c : CARD) frond(level, top, c[0], c[1], PROF_LONG, lv, false);
        for (int[] c : DIAG) frond(level, top, c[0], c[1], PROF_DIAG, lv, false);
        return true;
    }

    // ------------------------------------------------------------ mango
    private static boolean mango(WorldGenLevel level, BlockPos base, RandomSource r) {
        if (!isGround(level, base.below()) || !free(level, base)) return false;
        int h = 4 + r.nextInt(3);
        for (int i = 0; i < h; i++) if (!free(level, base.above(i))) return false;
        BlockState log = Blocks.OAK_LOG.defaultBlockState();
        for (int i = 0; i < h; i++) level.setBlock(base.above(i), log, 3);
        BlockPos top = base.above(h - 1);
        BlockState lv = leaf(ModBlocks.MANGO_LEAVES);
        for (int x = -3; x <= 3; x++)
            for (int y = -1; y <= 2; y++)
                for (int z = -3; z <= 3; z++) {
                    double dist = x * x + z * z + (y - 0.5) * (y - 0.5) * 2.2;
                    if (dist > 9.5) continue;
                    if (dist > 6.5 && r.nextInt(5) == 0) continue;
                    put(level, top.offset(x, y, z), lv);
                }
        return true;
    }

    // ------------------------------------------------------------ banana
    private static boolean banana(WorldGenLevel level, BlockPos base, RandomSource r) {
        if (!isGround(level, base.below()) || !free(level, base)) return false;
        int h = 3 + r.nextInt(2);
        for (int i = 0; i < h; i++) if (!free(level, base.above(i))) return false;
        BlockState log = Blocks.JUNGLE_LOG.defaultBlockState();
        for (int i = 0; i < h; i++) level.setBlock(base.above(i), log, 3);
        BlockPos top = base.above(h - 1);
        BlockState lv = leaf(ModBlocks.BANANA_LEAVES);
        put(level, top.above(), lv);
        for (int[] c : CARD) put(level, top.offset(c[0], 0, c[1]), lv);
        for (int[] c : CARD) frond(level, top, c[0], c[1], PROF_BANANA, lv, true);
        for (int[] c : DIAG) frond(level, top, c[0], c[1], PROF_BANANA, lv, true);
        return true;
    }

    // ------------------------------------------------------------ pineapple patch
    private static boolean pineapples(WorldGenLevel level, BlockPos origin, RandomSource r) {
        boolean any = false;
        int tries = 4 + r.nextInt(5);
        for (int i = 0; i < tries; i++) {
            int rx = r.nextInt(7) - 3, rz = r.nextInt(7) - 3;
            for (int dy = 3; dy >= -3; dy--) {
                BlockPos p = origin.offset(rx, dy, rz);
                if (isGround(level, p.below()) && free(level, p) && level.getBlockState(p).getFluidState().isEmpty()) {
                    level.setBlock(p, ModBlocks.PINEAPPLE_PLANT.defaultBlockState(), 3);
                    any = true;
                    break;
                }
            }
        }
        return any;
    }

    // ------------------------------------------------------------ wild grapes
    private static boolean grapes(WorldGenLevel level, BlockPos origin, RandomSource r) {
        boolean any = false;
        int tries = 3 + r.nextInt(4);
        for (int i = 0; i < tries; i++) {
            int rx = r.nextInt(5) - 2, rz = r.nextInt(5) - 2;
            for (int dy = 3; dy >= -3; dy--) {
                BlockPos p = origin.offset(rx, dy, rz);
                if (isGround(level, p.below()) && free(level, p) && level.getBlockState(p).getFluidState().isEmpty()) {
                    level.setBlock(p, ModBlocks.GRAPE_VINE.defaultBlockState().setValue(GrapeVineBlock.AGE, 3), 3);
                    any = true;
                    break;
                }
            }
        }
        return any;
    }

    // ------------------------------------------------ wild tobacco
    private static boolean tobacco(WorldGenLevel level, BlockPos origin, RandomSource r) {
        boolean any = false;
        int tries = 3 + r.nextInt(4);
        for (int i = 0; i < tries; i++) {
            int rx = r.nextInt(5) - 2, rz = r.nextInt(5) - 2;
            for (int dy = 3; dy >= -3; dy--) {
                BlockPos p = origin.offset(rx, dy, rz);
                if (isGround(level, p.below()) && free(level, p) && level.getBlockState(p).getFluidState().isEmpty()) {
                    level.setBlock(p, ModBlocks.TOBACCO_PLANT.defaultBlockState().setValue(TobaccoPlantBlock.AGE, r.nextInt(4)), 3);
                    any = true;
                    break;
                }
            }
        }
        return any;
    }

    private static boolean wild(WorldGenLevel level, BlockPos origin, RandomSource r, Block plant) {
        boolean any = false;
        int tries = 3 + r.nextInt(4);
        for (int i = 0; i < tries; i++) {
            int rx = r.nextInt(5) - 2, rz = r.nextInt(5) - 2;
            for (int dy = 3; dy >= -3; dy--) {
                BlockPos p = origin.offset(rx, dy, rz);
                if (isGround(level, p.below()) && free(level, p) && level.getBlockState(p).getFluidState().isEmpty()) {
                    level.setBlock(p, plant.defaultBlockState().setValue(AgedPlantBlock.AGE, r.nextInt(4)), 3);
                    any = true;
                    break;
                }
            }
        }
        return any;
    }
}
