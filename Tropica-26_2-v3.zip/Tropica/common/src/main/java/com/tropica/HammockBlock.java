package com.tropica;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;

/**
 * A hammock is a 2-block long bed. It can only be placed between two supports
 * (logs or fences) that have exactly 2 free blocks between them.
 * Sleeping works exactly like a normal bed (night only, sets the spawn point).
 */
public class HammockBlock extends BedBlock {
    public HammockBlock(Properties props) {
        super(DyeColor.BROWN, props);
    }

    /** No block entity: the hammock is rendered from its JSON model, not as a bed. */
    // В 26.x у BedBlock этого метода может не быть, поэтому без @Override.
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return null; }

    @Override
    protected RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }

    public static boolean isSupport(BlockState s) {
        return s.is(BlockTags.LOGS) || s.is(BlockTags.FENCES);
    }

    /** Both supports present? Works for either half of the hammock. */
    public static boolean hasSupports(BlockGetter level, BlockPos pos, BlockState state) {
        Direction facing = state.getValue(FACING);
        BlockPos foot = state.getValue(PART) == BedPart.FOOT ? pos : pos.relative(facing.getOpposite());
        BlockPos head = foot.relative(facing);
        return isSupport(level.getBlockState(foot.relative(facing.getOpposite())))
                && isSupport(level.getBlockState(head.relative(facing)));
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        BlockState st = super.getStateForPlacement(ctx);
        if (st == null) return null;
        BlockPos foot = ctx.getClickedPos();
        Direction facing = st.getValue(FACING);
        BlockPos head = foot.relative(facing);
        boolean ok = isSupport(ctx.getLevel().getBlockState(foot.relative(facing.getOpposite())))
                && isSupport(ctx.getLevel().getBlockState(head.relative(facing)));
        if (!ok) {
            if (ctx.getPlayer() != null && ctx.getLevel() instanceof ServerLevel) {
                Compat.actionBar(ctx.getPlayer(), Component.translatable("tropica.hammock.nosupport"));
            }
            return null;
        }
        return st;
    }
}
