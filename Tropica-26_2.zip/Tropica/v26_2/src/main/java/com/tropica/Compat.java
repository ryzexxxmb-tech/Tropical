package com.tropica;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.Consumables;
import net.minecraft.world.item.Item;

/** Код, который отличается между версиями Minecraft. */
final class Compat {
    private Compat() {}

    static Item.Properties drinkable(Item.Properties p) {
        return p.component(DataComponents.CONSUMABLE, Consumables.DEFAULT_DRINK);
    }
}
